import { z } from 'zod';

/**
 * Zod schema for Tour validation
 */
export const TourSchema = z.object({
  id: z.string().uuid(),
  title: z.string().min(1, { message: "Title is required" }),
  availableLanguagesKeys: z.array(z.enum(['Polish', 'English', 'German'])),
  basePricePLN: z.number(),
  durationMinutes: z.number().int(),
  fullDescription: z.string().min(1, { message: "Full Description is required" }),
  imageUrl: z.string().optional(),
  publishedStatusKey: z.enum(['Draft', 'InReview', 'Approved', 'Published', 'Archived']),
  rating: z.number().optional(),
  slug: z.string().min(1, { message: "Slug is required" }),
  summary: z.string().min(1, { message: "Summary is required" }),
  themeKey: z.enum(['Historical', 'Cultural', 'Nature']),
  tourLocation: z.object({ id: z.string().uuid(), name1: z.string() }),
});

/**
 * Schema for creating a new Tour (omits system-generated ID)
 */
export const CreateTourSchema = TourSchema.omit({ id: true });

/**
 * Schema for updating an existing Tour
 */
export const UpdateTourSchema = TourSchema;

export type TourInput = z.infer<typeof TourSchema>;
export type CreateTourInput = z.infer<typeof CreateTourSchema>;
export type UpdateTourInput = z.infer<typeof UpdateTourSchema>;