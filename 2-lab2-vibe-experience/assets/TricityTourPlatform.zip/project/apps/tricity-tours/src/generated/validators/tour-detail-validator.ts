import { z } from 'zod';

/**
 * Zod schema for TourDetail validation
 */
export const TourDetailSchema = z.object({
  id: z.string().uuid(),
  tourDetailName: z.string().min(1, { message: "Tour Detail Name is required" }),
  accessibilityNotes: z.string().optional(),
  cancellationPolicy: z.string().min(1, { message: "Cancellation Policy is required" }),
  galleryImageURLs: z.string().optional(),
  latitude: z.number(),
  longitude: z.number(),
  meetingPoint: z.string().min(1, { message: "Meeting Point is required" }),
  routeHighlights: z.string().min(1, { message: "Route Highlights is required" }),
  tour: z.object({ id: z.string().uuid(), title: z.string() }),
});

/**
 * Schema for creating a new TourDetail (omits system-generated ID)
 */
export const CreateTourDetailSchema = TourDetailSchema.omit({ id: true });

/**
 * Schema for updating an existing TourDetail
 */
export const UpdateTourDetailSchema = TourDetailSchema;

export type TourDetailInput = z.infer<typeof TourDetailSchema>;
export type CreateTourDetailInput = z.infer<typeof CreateTourDetailSchema>;
export type UpdateTourDetailInput = z.infer<typeof UpdateTourDetailSchema>;