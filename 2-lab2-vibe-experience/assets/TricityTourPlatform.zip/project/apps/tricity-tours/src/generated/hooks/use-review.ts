import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ReviewService } from "../services/review-service";
import type { Review } from "../models/review-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Review records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, reviewName, rating, reviewerName, reviewText, verified, visitDate
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useReviewList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["review-list", options],
    queryFn: () => ReviewService.getAll(options),
  });
}

/**
 * Retrieve a single Review record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useReview(id: string) {
  return useQuery({
    queryKey: ["review", id],
    queryFn: () => ReviewService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Review record.
 * @remarks Form validation: use CreateReviewSchema with zodResolver for type-safe create forms
 */
export function useCreateReview() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Review, "id">) => ReviewService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["review-list"] });
    },
  });
}

/**
 * Update an existing Review record.
 * @remarks Form validation: use UpdateReviewSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateReview() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Review, "id">>;
    }) => ReviewService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["review-list"] });
      client.invalidateQueries({ queryKey: ["review", variables.id] });
    },
  });
}

/**
 * Delete a Review record by its unique identifier.
 */
export function useDeleteReview() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => ReviewService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["review-list"] });
      client.invalidateQueries({ queryKey: ["review", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Review_DATA_SOURCE_TYPE = 'InMemory' as const;

export { ReviewSchema, CreateReviewSchema, UpdateReviewSchema } from "../validators/review-validator";
export type { ReviewInput, CreateReviewInput, UpdateReviewInput } from "../validators/review-validator";