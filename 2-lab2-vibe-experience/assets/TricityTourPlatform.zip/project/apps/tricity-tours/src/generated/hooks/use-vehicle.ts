import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { VehicleService } from "../services/vehicle-service";
import type { Vehicle } from "../models/vehicle-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Vehicle records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, name1, accessibilityEquipped, imageUrl, registration, seats, statusKey, vehicleTypeKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useVehicleList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["vehicle-list", options],
    queryFn: () => VehicleService.getAll(options),
  });
}

/**
 * Retrieve a single Vehicle record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useVehicle(id: string) {
  return useQuery({
    queryKey: ["vehicle", id],
    queryFn: () => VehicleService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Vehicle record.
 * @remarks Form validation: use CreateVehicleSchema with zodResolver for type-safe create forms
 */
export function useCreateVehicle() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Vehicle, "id">) => VehicleService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["vehicle-list"] });
    },
  });
}

/**
 * Update an existing Vehicle record.
 * @remarks Form validation: use UpdateVehicleSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateVehicle() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Vehicle, "id">>;
    }) => VehicleService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["vehicle-list"] });
      client.invalidateQueries({ queryKey: ["vehicle", variables.id] });
    },
  });
}

/**
 * Delete a Vehicle record by its unique identifier.
 */
export function useDeleteVehicle() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => VehicleService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["vehicle-list"] });
      client.invalidateQueries({ queryKey: ["vehicle", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Vehicle_DATA_SOURCE_TYPE = 'InMemory' as const;

export { VehicleSchema, CreateVehicleSchema, UpdateVehicleSchema } from "../validators/vehicle-validator";
export type { VehicleInput, CreateVehicleInput, UpdateVehicleInput } from "../validators/vehicle-validator";