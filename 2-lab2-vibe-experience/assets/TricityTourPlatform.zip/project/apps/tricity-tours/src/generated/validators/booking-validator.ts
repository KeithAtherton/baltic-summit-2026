import { z } from 'zod';

/**
 * Zod schema for Booking validation
 */
export const BookingSchema = z.object({
  id: z.string().uuid(),
  bookingReference: z.string().min(1, { message: "Booking Reference is required" }),
  bookingStatusKey: z.enum(['Pending', 'Confirmed', 'Completed', 'Cancelled', 'NoShow']),
  cancellationDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  cancellationReason: z.string().optional(),
  createdDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Created Datetime is required" }),
  customerEmail: z.string().email().min(1, { message: "Customer Email is required" }),
  customerName: z.string().min(1, { message: "Customer Name is required" }),
  groupSize: z.number().int(),
  paymentStatusKey: z.enum(['Pending', 'Paid', 'Refunded', 'Failed']),
  preferredLanguageKey: z.enum(['Polish', 'English', 'German']),
  specialRequests: z.string().optional(),
  totalAmountPLN: z.number(),
  tourSchedule: z.object({ id: z.string().uuid(), tourScheduleName: z.string() }),
});

/**
 * Schema for creating a new Booking (omits system-generated ID)
 */
export const CreateBookingSchema = BookingSchema.omit({ id: true });

/**
 * Schema for updating an existing Booking
 */
export const UpdateBookingSchema = BookingSchema;

export type BookingInput = z.infer<typeof BookingSchema>;
export type CreateBookingInput = z.infer<typeof CreateBookingSchema>;
export type UpdateBookingInput = z.infer<typeof UpdateBookingSchema>;