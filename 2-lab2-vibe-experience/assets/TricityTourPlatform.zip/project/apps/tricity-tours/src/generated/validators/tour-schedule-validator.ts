import { z } from 'zod';

/**
 * Zod schema for TourSchedule validation
 */
export const TourScheduleSchema = z.object({
  id: z.string().uuid(),
  tourScheduleName: z.string().min(1, { message: "Tour Schedule Name is required" }),
  bookedSeats: z.number().int(),
  capacity: z.number().int(),
  endDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "End Datetime is required" }),
  guide: z.object({ id: z.string().uuid(), name1: z.string() }),
  startDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Start Datetime is required" }),
  statusKey: z.enum(['Scheduled', 'Boarding', 'InProgress', 'Completed', 'Cancelled']),
  tour: z.object({ id: z.string().uuid(), title: z.string() }),
  vehicle: z.object({ id: z.string().uuid(), name1: z.string() }).optional(),
});

/**
 * Schema for creating a new TourSchedule (omits system-generated ID)
 */
export const CreateTourScheduleSchema = TourScheduleSchema.omit({ id: true });

/**
 * Schema for updating an existing TourSchedule
 */
export const UpdateTourScheduleSchema = TourScheduleSchema;

export type TourScheduleInput = z.infer<typeof TourScheduleSchema>;
export type CreateTourScheduleInput = z.infer<typeof CreateTourScheduleSchema>;
export type UpdateTourScheduleInput = z.infer<typeof UpdateTourScheduleSchema>;