import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TourDetailService } from "../services/tour-detail-service";
import type { TourDetail } from "../models/tour-detail-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all TourDetail records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, tourDetailName, accessibilityNotes, cancellationPolicy, galleryImageURLs, latitude, longitude, meetingPoint, routeHighlights
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useTourDetailList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["tourDetail-list", options],
    queryFn: () => TourDetailService.getAll(options),
  });
}

/**
 * Retrieve a single TourDetail record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useTourDetail(id: string) {
  return useQuery({
    queryKey: ["tourDetail", id],
    queryFn: () => TourDetailService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new TourDetail record.
 * @remarks Form validation: use CreateTourDetailSchema with zodResolver for type-safe create forms
 */
export function useCreateTourDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<TourDetail, "id">) => TourDetailService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["tourDetail-list"] });
    },
  });
}

/**
 * Update an existing TourDetail record.
 * @remarks Form validation: use UpdateTourDetailSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateTourDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<TourDetail, "id">>;
    }) => TourDetailService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["tourDetail-list"] });
      client.invalidateQueries({ queryKey: ["tourDetail", variables.id] });
    },
  });
}

/**
 * Delete a TourDetail record by its unique identifier.
 */
export function useDeleteTourDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => TourDetailService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["tourDetail-list"] });
      client.invalidateQueries({ queryKey: ["tourDetail", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const TourDetail_DATA_SOURCE_TYPE = 'InMemory' as const;

export { TourDetailSchema, CreateTourDetailSchema, UpdateTourDetailSchema } from "../validators/tour-detail-validator";
export type { TourDetailInput, CreateTourDetailInput, UpdateTourDetailInput } from "../validators/tour-detail-validator";