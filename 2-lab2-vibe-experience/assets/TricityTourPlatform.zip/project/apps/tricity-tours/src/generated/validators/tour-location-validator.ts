import { z } from 'zod';

/**
 * Zod schema for TourLocation validation
 */
export const TourLocationSchema = z.object({
  id: z.string().uuid(),
  name1: z.string().min(1, { message: "Name is required" }),
  areaDescription: z.string().optional(),
  cityKey: z.enum(['Gdynia', 'Gdansk', 'Sopot', 'TricityCoast']),
  imageUrl: z.string().optional(),
});

/**
 * Schema for creating a new TourLocation (omits system-generated ID)
 */
export const CreateTourLocationSchema = TourLocationSchema.omit({ id: true });

/**
 * Schema for updating an existing TourLocation
 */
export const UpdateTourLocationSchema = TourLocationSchema;

export type TourLocationInput = z.infer<typeof TourLocationSchema>;
export type CreateTourLocationInput = z.infer<typeof CreateTourLocationSchema>;
export type UpdateTourLocationInput = z.infer<typeof UpdateTourLocationSchema>;