import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { GuideService } from "../services/guide-service";
import type { Guide } from "../models/guide-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Guide records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, name1, languagesKeys, phone, rating, specialtiesKeys, statusKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useGuideList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["guide-list", options],
    queryFn: () => GuideService.getAll(options),
  });
}

/**
 * Retrieve a single Guide record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useGuide(id: string) {
  return useQuery({
    queryKey: ["guide", id],
    queryFn: () => GuideService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Guide record.
 * @remarks Form validation: use CreateGuideSchema with zodResolver for type-safe create forms
 */
export function useCreateGuide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Guide, "id">) => GuideService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["guide-list"] });
    },
  });
}

/**
 * Update an existing Guide record.
 * @remarks Form validation: use UpdateGuideSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateGuide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Guide, "id">>;
    }) => GuideService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["guide-list"] });
      client.invalidateQueries({ queryKey: ["guide", variables.id] });
    },
  });
}

/**
 * Delete a Guide record by its unique identifier.
 */
export function useDeleteGuide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => GuideService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["guide-list"] });
      client.invalidateQueries({ queryKey: ["guide", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Guide_DATA_SOURCE_TYPE = 'InMemory' as const;

export { GuideSchema, CreateGuideSchema, UpdateGuideSchema } from "../validators/guide-validator";
export type { GuideInput, CreateGuideInput, UpdateGuideInput } from "../validators/guide-validator";