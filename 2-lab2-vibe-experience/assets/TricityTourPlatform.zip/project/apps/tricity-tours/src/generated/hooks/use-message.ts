import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageService } from "../services/message-service";
import type { Message } from "../models/message-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Message records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, messageName, messageText, readFlag, senderRoleKey, sentDatetime
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useMessageList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["message-list", options],
    queryFn: () => MessageService.getAll(options),
  });
}

/**
 * Retrieve a single Message record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useMessage(id: string) {
  return useQuery({
    queryKey: ["message", id],
    queryFn: () => MessageService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Message record.
 * @remarks Form validation: use CreateMessageSchema with zodResolver for type-safe create forms
 */
export function useCreateMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Message, "id">) => MessageService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["message-list"] });
    },
  });
}

/**
 * Update an existing Message record.
 * @remarks Form validation: use UpdateMessageSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Message, "id">>;
    }) => MessageService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["message-list"] });
      client.invalidateQueries({ queryKey: ["message", variables.id] });
    },
  });
}

/**
 * Delete a Message record by its unique identifier.
 */
export function useDeleteMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => MessageService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["message-list"] });
      client.invalidateQueries({ queryKey: ["message", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Message_DATA_SOURCE_TYPE = 'InMemory' as const;

export { MessageSchema, CreateMessageSchema, UpdateMessageSchema } from "../validators/message-validator";
export type { MessageInput, CreateMessageInput, UpdateMessageInput } from "../validators/message-validator";