import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TourService } from "../services/tour-service";
import type { Tour } from "../models/tour-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Tour records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, title, availableLanguagesKeys, basePricePLN, durationMinutes, fullDescription, imageUrl, publishedStatusKey, rating, slug, summary, themeKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useTourList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["tour-list", options],
    queryFn: () => TourService.getAll(options),
  });
}

/**
 * Retrieve a single Tour record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useTour(id: string) {
  return useQuery({
    queryKey: ["tour", id],
    queryFn: () => TourService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Tour record.
 * @remarks Form validation: use CreateTourSchema with zodResolver for type-safe create forms
 */
export function useCreateTour() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Tour, "id">) => TourService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["tour-list"] });
    },
  });
}

/**
 * Update an existing Tour record.
 * @remarks Form validation: use UpdateTourSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateTour() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Tour, "id">>;
    }) => TourService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["tour-list"] });
      client.invalidateQueries({ queryKey: ["tour", variables.id] });
    },
  });
}

/**
 * Delete a Tour record by its unique identifier.
 */
export function useDeleteTour() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => TourService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["tour-list"] });
      client.invalidateQueries({ queryKey: ["tour", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Tour_DATA_SOURCE_TYPE = 'InMemory' as const;

export { TourSchema, CreateTourSchema, UpdateTourSchema } from "../validators/tour-validator";
export type { TourInput, CreateTourInput, UpdateTourInput } from "../validators/tour-validator";