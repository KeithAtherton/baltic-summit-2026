import { z } from 'zod';

/**
 * Zod schema for Vehicle validation
 */
export const VehicleSchema = z.object({
  id: z.string().uuid(),
  name1: z.string().min(1, { message: "Name is required" }),
  accessibilityEquipped: z.boolean(),
  imageUrl: z.string().optional(),
  registration: z.string().min(1, { message: "Registration is required" }),
  seats: z.number().int(),
  statusKey: z.enum(['Available', 'Assigned', 'Maintenance', 'OutOfService']),
  vehicleTypeKey: z.enum(['Minibus', 'Coach', 'ElectricCart', 'PassengerVan', 'Boat']),
});

/**
 * Schema for creating a new Vehicle (omits system-generated ID)
 */
export const CreateVehicleSchema = VehicleSchema.omit({ id: true });

/**
 * Schema for updating an existing Vehicle
 */
export const UpdateVehicleSchema = VehicleSchema;

export type VehicleInput = z.infer<typeof VehicleSchema>;
export type CreateVehicleInput = z.infer<typeof CreateVehicleSchema>;
export type UpdateVehicleInput = z.infer<typeof UpdateVehicleSchema>;