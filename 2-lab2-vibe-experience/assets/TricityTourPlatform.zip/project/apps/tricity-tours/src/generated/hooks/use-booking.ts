import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BookingService } from "../services/booking-service";
import type { Booking } from "../models/booking-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Booking records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, bookingReference, bookingStatusKey, cancellationDatetime, cancellationReason, createdDatetime, customerEmail, customerName, groupSize, paymentStatusKey, preferredLanguageKey, specialRequests, totalAmountPLN
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBookingList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["booking-list", options],
    queryFn: () => BookingService.getAll(options),
  });
}

/**
 * Retrieve a single Booking record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBooking(id: string) {
  return useQuery({
    queryKey: ["booking", id],
    queryFn: () => BookingService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Booking record.
 * @remarks Form validation: use CreateBookingSchema with zodResolver for type-safe create forms
 */
export function useCreateBooking() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Booking, "id">) => BookingService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["booking-list"] });
    },
  });
}

/**
 * Update an existing Booking record.
 * @remarks Form validation: use UpdateBookingSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBooking() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Booking, "id">>;
    }) => BookingService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["booking-list"] });
      client.invalidateQueries({ queryKey: ["booking", variables.id] });
    },
  });
}

/**
 * Delete a Booking record by its unique identifier.
 */
export function useDeleteBooking() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BookingService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["booking-list"] });
      client.invalidateQueries({ queryKey: ["booking", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Booking_DATA_SOURCE_TYPE = 'InMemory' as const;

export { BookingSchema, CreateBookingSchema, UpdateBookingSchema } from "../validators/booking-validator";
export type { BookingInput, CreateBookingInput, UpdateBookingInput } from "../validators/booking-validator";