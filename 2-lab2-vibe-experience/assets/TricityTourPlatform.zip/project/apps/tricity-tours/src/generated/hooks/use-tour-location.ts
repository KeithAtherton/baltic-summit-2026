import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TourLocationService } from "../services/tour-location-service";
import type { TourLocation } from "../models/tour-location-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all TourLocation records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, name1, areaDescription, cityKey, imageUrl
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useTourLocationList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["tourLocation-list", options],
    queryFn: () => TourLocationService.getAll(options),
  });
}

/**
 * Retrieve a single TourLocation record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useTourLocation(id: string) {
  return useQuery({
    queryKey: ["tourLocation", id],
    queryFn: () => TourLocationService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new TourLocation record.
 * @remarks Form validation: use CreateTourLocationSchema with zodResolver for type-safe create forms
 */
export function useCreateTourLocation() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<TourLocation, "id">) => TourLocationService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["tourLocation-list"] });
    },
  });
}

/**
 * Update an existing TourLocation record.
 * @remarks Form validation: use UpdateTourLocationSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateTourLocation() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<TourLocation, "id">>;
    }) => TourLocationService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["tourLocation-list"] });
      client.invalidateQueries({ queryKey: ["tourLocation", variables.id] });
    },
  });
}

/**
 * Delete a TourLocation record by its unique identifier.
 */
export function useDeleteTourLocation() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => TourLocationService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["tourLocation-list"] });
      client.invalidateQueries({ queryKey: ["tourLocation", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const TourLocation_DATA_SOURCE_TYPE = 'InMemory' as const;

export { TourLocationSchema, CreateTourLocationSchema, UpdateTourLocationSchema } from "../validators/tour-location-validator";
export type { TourLocationInput, CreateTourLocationInput, UpdateTourLocationInput } from "../validators/tour-location-validator";