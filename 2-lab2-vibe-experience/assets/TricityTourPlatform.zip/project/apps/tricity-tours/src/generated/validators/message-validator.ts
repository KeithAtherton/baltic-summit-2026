import { z } from 'zod';

/**
 * Zod schema for Message validation
 */
export const MessageSchema = z.object({
  id: z.string().uuid(),
  messageName: z.string().min(1, { message: "Message Name is required" }),
  booking: z.object({ id: z.string().uuid(), bookingReference: z.string() }),
  messageText: z.string().min(1, { message: "Message Text is required" }),
  readFlag: z.boolean(),
  senderRoleKey: z.enum(['Customer', 'Guide', 'Operator']),
  sentDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Sent Datetime is required" }),
});

/**
 * Schema for creating a new Message (omits system-generated ID)
 */
export const CreateMessageSchema = MessageSchema.omit({ id: true });

/**
 * Schema for updating an existing Message
 */
export const UpdateMessageSchema = MessageSchema;

export type MessageInput = z.infer<typeof MessageSchema>;
export type CreateMessageInput = z.infer<typeof CreateMessageSchema>;
export type UpdateMessageInput = z.infer<typeof UpdateMessageSchema>;