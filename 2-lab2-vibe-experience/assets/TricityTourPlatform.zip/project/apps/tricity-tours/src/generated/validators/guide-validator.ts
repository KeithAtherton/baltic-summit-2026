import { z } from 'zod';

/**
 * Zod schema for Guide validation
 */
export const GuideSchema = z.object({
  id: z.string().uuid(),
  name1: z.string().min(1, { message: "Name is required" }),
  languagesKeys: z.array(z.enum(['Polish', 'English', 'German'])),
  phone: z.string().min(1, { message: "Phone is required" }),
  rating: z.number().optional(),
  specialtiesKeys: z.array(z.enum(['History', 'Architecture', 'Maritime', 'Nature', 'FoodAndCulture'])),
  statusKey: z.enum(['Available', 'Assigned', 'Unavailable', 'Inactive']),
});

/**
 * Schema for creating a new Guide (omits system-generated ID)
 */
export const CreateGuideSchema = GuideSchema.omit({ id: true });

/**
 * Schema for updating an existing Guide
 */
export const UpdateGuideSchema = GuideSchema;

export type GuideInput = z.infer<typeof GuideSchema>;
export type CreateGuideInput = z.infer<typeof CreateGuideSchema>;
export type UpdateGuideInput = z.infer<typeof UpdateGuideSchema>;