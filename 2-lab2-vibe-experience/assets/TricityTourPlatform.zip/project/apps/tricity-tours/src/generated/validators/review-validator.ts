import { z } from 'zod';

/**
 * Zod schema for Review validation
 */
export const ReviewSchema = z.object({
  id: z.string().uuid(),
  reviewName: z.string().min(1, { message: "Review Name is required" }),
  rating: z.number().int(),
  reviewerName: z.string().min(1, { message: "Reviewer Name is required" }),
  reviewText: z.string().min(1, { message: "Review Text is required" }),
  tour: z.object({ id: z.string().uuid(), title: z.string() }),
  verified: z.boolean(),
  visitDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format").min(1, { message: "Visit Date is required" }),
});

/**
 * Schema for creating a new Review (omits system-generated ID)
 */
export const CreateReviewSchema = ReviewSchema.omit({ id: true });

/**
 * Schema for updating an existing Review
 */
export const UpdateReviewSchema = ReviewSchema;

export type ReviewInput = z.infer<typeof ReviewSchema>;
export type CreateReviewInput = z.infer<typeof CreateReviewSchema>;
export type UpdateReviewInput = z.infer<typeof UpdateReviewSchema>;