import { z } from 'zod';

/**
 * Zod schema for Notification validation
 */
export const NotificationSchema = z.object({
  id: z.string().uuid(),
  title: z.string().min(1, { message: "Title is required" }),
  body: z.string().min(1, { message: "Body is required" }),
  booking: z.object({ id: z.string().uuid(), bookingReference: z.string() }).optional(),
  channelKey: z.enum(['Email', 'SMS', 'Push', 'InApp']),
  scheduledDatetime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Scheduled Datetime is required" }),
  sentStatusKey: z.enum(['Scheduled', 'Sent', 'Failed', 'Cancelled']),
});

/**
 * Schema for creating a new Notification (omits system-generated ID)
 */
export const CreateNotificationSchema = NotificationSchema.omit({ id: true });

/**
 * Schema for updating an existing Notification
 */
export const UpdateNotificationSchema = NotificationSchema;

export type NotificationInput = z.infer<typeof NotificationSchema>;
export type CreateNotificationInput = z.infer<typeof CreateNotificationSchema>;
export type UpdateNotificationInput = z.infer<typeof UpdateNotificationSchema>;