import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TourScheduleService } from "../services/tour-schedule-service";
import type { TourSchedule } from "../models/tour-schedule-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all TourSchedule records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, tourScheduleName, bookedSeats, capacity, endDatetime, startDatetime, statusKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useTourScheduleList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["tourSchedule-list", options],
    queryFn: () => TourScheduleService.getAll(options),
  });
}

/**
 * Retrieve a single TourSchedule record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useTourSchedule(id: string) {
  return useQuery({
    queryKey: ["tourSchedule", id],
    queryFn: () => TourScheduleService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new TourSchedule record.
 * @remarks Form validation: use CreateTourScheduleSchema with zodResolver for type-safe create forms
 */
export function useCreateTourSchedule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<TourSchedule, "id">) => TourScheduleService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["tourSchedule-list"] });
    },
  });
}

/**
 * Update an existing TourSchedule record.
 * @remarks Form validation: use UpdateTourScheduleSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateTourSchedule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<TourSchedule, "id">>;
    }) => TourScheduleService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["tourSchedule-list"] });
      client.invalidateQueries({ queryKey: ["tourSchedule", variables.id] });
    },
  });
}

/**
 * Delete a TourSchedule record by its unique identifier.
 */
export function useDeleteTourSchedule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => TourScheduleService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["tourSchedule-list"] });
      client.invalidateQueries({ queryKey: ["tourSchedule", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const TourSchedule_DATA_SOURCE_TYPE = 'InMemory' as const;

export { TourScheduleSchema, CreateTourScheduleSchema, UpdateTourScheduleSchema } from "../validators/tour-schedule-validator";
export type { TourScheduleInput, CreateTourScheduleInput, UpdateTourScheduleInput } from "../validators/tour-schedule-validator";