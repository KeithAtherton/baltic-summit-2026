import TourPlatform from '@/pages/tour-platform';

export default function HomePage() {
  return <TourPlatform />;
}
