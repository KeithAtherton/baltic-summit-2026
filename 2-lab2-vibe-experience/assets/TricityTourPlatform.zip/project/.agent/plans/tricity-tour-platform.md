# Tricity Tour Platform

## Product
- Build one role-aware application for customers, tour operators, and operational staff managing sightseeing tours across Gdynia, Gdańsk, Sopot, and the wider Tricity area.
- Use app-owned draft data with realistic local sample tours, schedules, bookings, reviews, guides, and vehicles; no existing Dataverse or SharePoint tables were found.
- Present an integration-ready demo: booking, availability, maps, payment, and notifications work as complete demo flows with clear boundaries for future production providers.

## Roles
- Customer: discover tours, review details and policies, book and pay, manage bookings, receive updates, and submit reviews.
- Operator: create and edit tours, manage departures and capacity, review bookings, communicate with participants, and monitor performance.
- Guide or dispatcher: view assigned schedules, participant details, guide assignments, and vehicle readiness.

## Navigation
- Use a persistent left sidebar because the unified platform has more than five primary destinations.
- Switch visible destinations and actions by role without creating separate applications.
- Customer destinations: Discover, My bookings, Notifications.
- Operator destinations: Overview, Tours, Schedule, Bookings, Operations, Messages, Analytics.

## Customer experience
- Discover: browse and filter tours by location, date, historical/cultural/nature theme, duration, language, and availability.
- Tour details: show multilingual description, itinerary, live capacity, duration, meeting point, interactive map panel, photo gallery, accessibility information, cancellation policy, and reviews.
- Booking: select departure and group size, enter participant details and special requests, review price, accept cancellation terms, and complete full-payment demo checkout.
- Confirmation: provide booking reference, payment status, meeting details, cancellation summary, and notification preferences.
- My bookings: show upcoming and past tours with booking details and cancellation actions governed by each tour policy.
- Reviews: allow verified participants to rate and review completed tours.
- Notifications: show reminder, schedule-change, cancellation, and operator-message updates with push opt-in controls.

## Operator experience
- Overview: summarize today's departures, capacity risks, new bookings, unresolved requests, guide coverage, and vehicle readiness.
- Tours: create, edit, publish, pause, and preview multilingual tour listings, galleries, routes, pricing, accessibility details, and cancellation policies.
- Schedule: manage departures, capacity, languages, guide assignment, vehicle assignment, and real-time availability.
- Bookings: search and filter reservations, inspect payment and cancellation status, review special requests, and update attendance.
- Operations: manage guide profiles, qualifications, languages, availability, and vehicle capacity, accessibility, and service status.
- Messages: send booking-specific or departure-wide updates to participants and retain conversation history.
- Analytics: visualize popular tours, bookings over time, occupancy, revenue, cancellations, theme demand, and language demand.

## Data entities
- Tour
- Tour Translation
- Tour Photo
- Tour Stop
- Departure
- Booking
- Booking Participant
- Payment
- Cancellation Policy
- Review
- Guide
- Guide Assignment
- Vehicle
- Vehicle Assignment
- Participant Message
- Notification

## Rules and states
- Calculate real-time availability from departure capacity minus active participant totals and update it after booking or cancellation.
- Require full payment to confirm a booking in the demo flow; represent provider processing and failure states without collecting real credentials.
- Apply tour-specific cancellation windows and refund outcomes consistently in tour details, checkout, booking management, and operator views.
- Restrict reviews to completed, confirmed bookings.
- Surface schedule changes to affected bookings and create participant notifications.
- Scope customer records to the signed-in user and use current user context for personalization and form defaults.

## Integrations
- Maps: use an interactive provider-ready map panel with Tricity route markers, stops, meeting points, and fallback location details.
- Payments: use a provider-ready full-payment checkout simulation with pending, successful, failed, and refunded states.
- Push notifications: provide opt-in and in-app simulation for reminders, updates, and cancellations, ready for a future push provider.
- No M365 runtime data is required for the initial scope; app-specific operational data remains in the app-owned model.

## Localization and accessibility
- Support Polish, English, and German for navigation, core customer content, tour translations, policies, and confirmation messaging.
- Include a persistent language selector and preserve language through discovery and checkout.
- Meet keyboard navigation, focus visibility, semantic labeling, contrast, reduced-motion, alt text, and screen-reader requirements.
- Clearly label accessible tours, vehicles, meeting points, and accommodation notes.

## Design direction
- Use a refined Baltic maritime identity: deep navy and sea-green semantic tokens, warm sand surfaces, crisp cartographic details, and restrained photography of coast, harbor, forest, and historic streets.
- Keep the interface data-first and operational, with compact cards, schedules, tables, status indicators, and clear booking calls to action.
- Use representative Tricity imagery and a polished responsive layout; avoid marketing-style hero sections and decorative gradients.

## Delivery boundaries
- Include functional demo CRUD and booking flows backed by draft in-memory tables and clearly disclose that draft data is not persistent.
- Do not connect live payment, map, or push credentials in this version.
- Do not create separate customer and operator apps; use role-aware routes and permissions within the single application.
- Seed realistic tours and operational records for Gdynia, Gdańsk, Sopot, coastal nature areas, harbor attractions, and historical districts.

## Validation
- Verify role-aware routing, filtering, availability calculations, booking and cancellation flows, multilingual switching, responsive behavior, and accessibility states.
- Verify every action has a working handler and every route has a corresponding page.
- Run full project validation after implementation and resolve all type, lint, and SDK issues.
