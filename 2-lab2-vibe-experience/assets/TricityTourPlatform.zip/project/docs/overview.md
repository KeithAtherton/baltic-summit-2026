# Tricity Tours

Tricity Tours is a unified sightseeing marketplace and operations workspace for Gdynia, Gdańsk, Sopot, and nearby coastal destinations. Visitors can discover tours by place, date, theme, and duration, review live capacity, explore routes and galleries, and complete a full-payment booking with clear cancellation terms.

## People and goals

- Visitors compare historical, cultural, and nature tours; choose a date and group size; add accessibility or other special requests; pay; and receive confirmations, reminders, and updates.
- Operators publish tours, maintain availability and schedules, manage bookings, communicate with participants, and monitor demand.
- Operations coordinators assign guides and vehicles while watching capacity, readiness, and conflicts.
- Guides review their upcoming assignments and participant notes.

## Core experiences

- Tour discovery with practical filters and multilingual content in Polish, English, and German.
- Detailed tour pages with route maps, photo galleries, reviews, inclusions, accessibility information, availability, and cancellation policy.
- Guided booking flow with group sizing, special requests, payment handoff, and confirmation.
- Role-aware operations workspace for tours, schedules, bookings, participant communication, guides, vehicles, and analytics.
- Integration-ready boundaries for maps, payments, push notifications, and real-time availability.

## Design direction

A crisp maritime operations aesthetic inspired by Gdynia’s modernist port: deep Baltic navy, sea-glass teal, warm navigational amber, precise grids, compact cards, and clear status signals. The experience is functional and information-dense while retaining generous spacing, keyboard support, strong contrast, visible focus states, reduced-motion respect, and descriptive labels.